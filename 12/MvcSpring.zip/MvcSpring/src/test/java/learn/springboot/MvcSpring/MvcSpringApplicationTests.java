package learn.springboot.MvcSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvcSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
